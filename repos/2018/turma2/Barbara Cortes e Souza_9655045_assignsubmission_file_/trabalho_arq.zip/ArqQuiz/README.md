# ArqQuiz
Jogo em javascript para auxiliar os alunos a estudarem e revisarem o conteúdo de Arquitetura de Computadores

![picture](imagens/screenshot.png)



## Authors

* **Lucas Turci** - *Initial work* - [lucasturci](https://github.com/lucasturci)
* **Barbara Cortes** - *Initial work* - [BarbaraCortes](https://github.com/BarbaraCortes)
* **Marina Kako** - *Initial work* - [kakomarina](https://github.com/kakomarina)
* **Fernanda Marana** - *Initial work* - [fertmarana](https://github.com/fertmarana)


