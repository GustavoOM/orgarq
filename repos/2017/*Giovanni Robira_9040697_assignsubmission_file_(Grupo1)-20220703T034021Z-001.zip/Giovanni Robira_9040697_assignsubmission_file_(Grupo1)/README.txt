Projeto Arquitetura de Computadores

--- Simulador MIPS ----

Nome:
Giovanni Robira
Guilherme Vicentim
Victor Luiz Mariano
João Vitor Sousa


Como usar : 
-executar a classe principal DesktopLauncher
-o arquivo de entrada de instruções
	core/assets/instrution.txt
