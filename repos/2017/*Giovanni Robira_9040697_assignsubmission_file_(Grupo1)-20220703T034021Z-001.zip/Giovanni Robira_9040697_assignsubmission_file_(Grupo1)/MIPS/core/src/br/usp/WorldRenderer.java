package br.usp;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Buttons;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Disposable;

import br.usp.components.Register;
import br.usp.components.Unity;
import br.usp.components.wire.CompWire;
import br.usp.components.wire.Wire;
import br.usp.utils.Constants;

public class WorldRenderer implements Disposable {
	
	private static WorldRenderer instance = null;
	
	private OrthographicCamera camera;
	
	private SpriteBatch batch;
	private SpriteBatch textBatch;
	private ShapeRenderer shapeRenderer;
	
	private WorldController worldController;
	
	private BitmapFont font;
	private GlyphLayout fontGlyph;
	
	private Sprite buttonPlay;
	private Sprite buttonHelp;
	private Sprite helpShow;
	
	private boolean drawHelp = false;
	
	public WorldRenderer() {
		camera = new OrthographicCamera(Constants.VIEWPORT_WIDTH, Constants.VIEWPORT_HEIGHT);
		camera.position.set(0.0f, 0.0f, 0.0f);
		camera.update();
		
		batch = new SpriteBatch();
		textBatch = new SpriteBatch();
		shapeRenderer = new ShapeRenderer();
		
		font = new BitmapFont(Gdx.files.internal("font.fnt"));
		font.getData().setScale(0.5f);
		font.setColor(Color.RED);
		fontGlyph = new GlyphLayout();
		
		buttonPlay = new Sprite(new Texture("button.png"));
		buttonPlay.setPosition(80.0f, 0.0f);
		buttonPlay.setScale(0.5f);
		
		buttonHelp = new Sprite(new Texture("help_button.png"));
		buttonHelp.setPosition(-50.0f, 0.0f);
		buttonHelp.setScale(0.5f);
		
		helpShow = new Sprite(new Texture("help_show.png"));
		helpShow.setScale(0.75f);
		helpShow.setPosition(0.5f, 80.0f);
	}
	
	public static WorldRenderer getIntance() {
		if (instance == null) {
			instance = new WorldRenderer();
		}
		return instance;
	}
	
	public void setWorldController(WorldController worldController) {
		this.worldController = worldController;
	}
	
	public void render() {
		worldController.cameraHelper.applyTo(camera);
		
		batch.setProjectionMatrix(camera.combined);
		shapeRenderer.setProjectionMatrix(camera.combined);
		
		// Desenha os fios
		Gdx.gl.glLineWidth(3);
		shapeRenderer.begin(ShapeType.Line);
		
		
		for(CompWire wire : worldController.wireComp) {
			wire.render(shapeRenderer);
		}
		shapeRenderer.end();
		
		// Renderiza os blocos
		batch.begin();
		
		for (Unity unity : worldController.unityList) {
			unity.render(batch);
		}
		
		batch.end();
		
		textBatch.begin();
		
		buttonPlay.draw(textBatch);
		buttonHelp.draw(textBatch);
		if(drawHelp) {
			helpShow.draw(textBatch);
		}
		
		for (Unity unity : worldController.unityList) {
			Vector3 coord = camera.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0.0f));
			if (unity instanceof Register && unity.sprite.getBoundingRectangle().contains(coord.x, coord.y)) {
				float x = Gdx.input.getX();
				float y = Gdx.graphics.getHeight() - Gdx.input.getY();
				
				if (x > Gdx.graphics.getWidth() / 2.0f) {
					fontGlyph.setText(font, ((Register) unity).instruction);
					x = x - fontGlyph.width;
				}
				
				font.draw(textBatch, ((Register) unity).instruction, x, y);
			}
		}
		
		
		textBatch.end();
		
		if(Gdx.input.isButtonPressed(Buttons.LEFT) && buttonPlay.getBoundingRectangle().contains(Gdx.input.getX(), Gdx.graphics.getHeight() - Gdx.input.getY())) {
			worldController.executePlay();
		}
		if(buttonHelp.getBoundingRectangle().contains(Gdx.input.getX(), Gdx.graphics.getHeight() - Gdx.input.getY())) {
			drawHelp= true;
		}else {
			drawHelp = false;
		}
	}
	
	public OrthographicCamera getCamera() {
		return camera;
	}
	
	public void resize(int width, int height) {
		camera.viewportWidth = (Constants.VIEWPORT_HEIGHT / height) * width;
		camera.update();
	}
	
	@Override
	public void dispose() {
		batch.dispose();
	}
	
}
