package br.usp.components.wire;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;

public class CompWire {
	
	private Wire[] wires;
	private int nextWireToAdd;
	
	public CompWire(int numWires) {
		wires = new Wire[numWires];
		nextWireToAdd = 0;
	}
	
	public CompWire(Wire wire) {
		this(1);
		this.addWire(wire);
	}
	
	public CompWire(CompWire cw1, CompWire cw2) {
		this(cw1.getSize() + cw2.getSize());
		for(int i = 0; i < cw1.getSize(); i++)
			this.addWire(cw1.getWires()[i]);
		for(int i = 0; i < cw2.getSize(); i++)
			this.addWire(cw2.getWires()[i]);
		
	}
	
	public void update(float deltaTime) {
		if (wires == null)
			return;
		
		for (int i = 0; i < wires.length; i++) {
			wires[i].update(deltaTime);
			
			if (i < wires.length - 1) {
				if (wires[i].isDone() && !wires[i+1].hasStarted())
					wires[i+1].start();
			}
		}
	}
	
	public void render(ShapeRenderer shapeRenderer) {
		if (wires == null)
			return;
		
		for (Wire wire : wires) {
			wire.render(shapeRenderer);
		}
	}
	
	public void addWire(Wire wire) {
		if (nextWireToAdd < wires.length)
			wires[nextWireToAdd++] = wire;
	}
	
	
	public void reset() {
		for (Wire wire : wires) {
			wire.reset();
		}
	}
	
	public void start() {
		wires[0].start();
	}
	
	public boolean isDone() {
		return wires[wires.length-1].isDone();
	}
	
	public int getSize() {
		return wires.length;
	}
	
	public Wire[] getWires() {
		return wires;
	}
	
}
