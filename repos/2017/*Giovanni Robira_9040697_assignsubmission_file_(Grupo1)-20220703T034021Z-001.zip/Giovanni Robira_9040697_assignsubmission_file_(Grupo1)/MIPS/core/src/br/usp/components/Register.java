package br.usp.components;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Register extends Unity {
		private static final Texture TEXTURE = new Texture("reg.png");
		
		private static final float WIDTH = 0.5f;
		private static final float HEIGHT = 8.0f;
		
		// Pontos de entrada
		public static final int ENTRY_TOP = 0;
		public static final int ENTRY_MIDDLE = 1;
		public static final int ENTRY_BOTTOM = 2;
		public static final int ENTRY_TOP_2 = 3;
		
		// Pontos de saida
		public static final int OUTPUT_TOP = 0;
		public static final int OUTPUT_MIDDLE = 1;
		public static final int OUTPUT_BOTTOM = 2;
		public static final int OUTPUT_TOP_2 = 3;
		public static final int OUTPUT_BOTTOM_2 = 4;
		
		public String instruction = " ";
		
		public Register(float x, float y) {
			super(new Vector2(x, y), TEXTURE, WIDTH, HEIGHT);
		}
		
		@Override
		protected void createEntryPoints() {
			entryPoints.add(new Vector2(0.0f, 3.4f));
			entryPoints.add(new Vector2(0.0f, 2.15f));
			entryPoints.add(new Vector2(0.0f, 0.45f));
			entryPoints.add(new Vector2(0.0f, 6.25f));
		}
		
		@Override
		protected void createOutputPoints() {
			outputPoints.add(new Vector2(WIDTH, 3.4f));
			outputPoints.add(new Vector2(WIDTH, 2.15f));
			outputPoints.add(new Vector2(WIDTH, 1.7f));
			outputPoints.add(new Vector2(WIDTH, 6.25f));
			outputPoints.add(new Vector2(WIDTH, 1.15f));
		}

		public void setInstruction(String str) {
			this.instruction = str;
		}
}
