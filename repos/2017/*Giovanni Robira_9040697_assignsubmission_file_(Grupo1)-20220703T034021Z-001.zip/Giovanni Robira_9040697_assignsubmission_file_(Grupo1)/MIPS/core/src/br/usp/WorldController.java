package br.usp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.math.Vector2;

import br.usp.components.CPU;
import br.usp.components.Data_Mem;
import br.usp.components.MUX;
import br.usp.components.Reg_Bank;
import br.usp.components.Register;
import br.usp.components.SignExtend;
import br.usp.components.StdBlock;
import br.usp.components.ULA;
import br.usp.components.Unity;
import br.usp.components.wire.CompWire;
import br.usp.components.wire.Wire;
import br.usp.utils.CameraHelper;

public class WorldController implements InputProcessor {
	
	public CameraHelper cameraHelper;
	
	// Objetos no mundo
	public List<Unity> unityList;
	public List<Wire> wireList;
	public List<CompWire> wireComp;
	
	private static final int BLK_INTRUCTION = 0;
	private static final int REGISTER_IF_ID = 1;
	private static final int REGISTER_BANK = 2;
	private static final int ULA_PC = 3;
	private static final int REGISTER_ID_EX = 4;
	private static final int ULA_EX = 5;
	private static final int ULA_ADD_4 = 6;
	private static final int MUX_EX = 7;
	private static final int REGISTER_EX_MEM = 8;
	private static final int DATA_MEM = 9;
	private static final int REGISTER_MEM_WB = 10;
	private static final int MUX_WB = 11;
	private static final int PC = 12;
	private static final int MUX_PC = 13;
	private static final int SIGN_EXTEND = 14;
	
	public int indexWireComp = 0;
	
	private static final int MAX_CYCLE = 5;
	private boolean runningCycle = false;
	private boolean pipelineSwicth = false;
	private int cycle = 0;
	public int[] pipeline = {-1, -1, -1, -1, -1};
	private int instructions[];
	public int indexInstruction = 0;
	public String instText[] = new String[15];
	
	public WorldController() {
		init();
	}
	
	public void init() {
		// criando camera
		cameraHelper = new CameraHelper();
		
		// criando lista de entidades blocos
		unityList = new ArrayList<Unity>();
		unityList.add(new StdBlock(-11.0f, -1.0f));			//0	BLOCO PADR�O
		unityList.add(new Register(-7.5f, -2.5f));			//1	IF/ID
		unityList.add(new Reg_Bank(-5.85f, -1.0f));			//2	Reg Bank
		unityList.add(new ULA(-11.0f, 2.75f));				//3 ULA ADD PC
		unityList.add(new Register( -3.0f, -2.5f));			//4	ID/EX
		unityList.add(new ULA(-0.5f, -0.6f));				//5 ULA
		unityList.add(new ULA(-0.5f, 2.25f));				//6 ULA ADD
		unityList.add(new MUX(-1.95f, -1.85f));				//7	MUX
		unityList.add(new Register(1.0f, -2.5f));			//8	EX/MEM
		unityList.add(new Data_Mem(2.0f, -1.0f));			//9 Data Mem
		unityList.add(new Register(5.0f, -2.5f));			//10MEM/WB
		unityList.add(new MUX(6.5f, -0.7f));				//11Mux
		unityList.add(new CPU(-13.0f, 1.85f));				//12 CPU
		unityList.add(new MUX(-14.3f, 1.5f));				//13 MUX PC
		unityList.add(new SignExtend(-5.6f, -3.0f));		//14 SIGN_EXTEND
		
		
		// criando lista de fios
		wireComp = new ArrayList<CompWire>();
		
		// Fios BLOCO PADRAO
		// 0 instruction - reg if id
		wireComp.add(new CompWire(new Wire(unityList.get(BLK_INTRUCTION).getOutputPoint(StdBlock.OUTPUT_TOP), new Vector2(unityList.get(REGISTER_IF_ID).getEntryPoint(Register.ENTRY_TOP)).add(0.5f, 0.0f))));
		
		// Fios Reg ID/IF
		// 1 reg id if - reg if ex
		wireComp.add(new CompWire(new Wire((new Vector2(unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_TOP_2))), unityList.get(REGISTER_ID_EX).getEntryPoint(Register.ENTRY_TOP_2))));
		
		
		// 2 reg id if - reg bank
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
				new Wire(
					unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE),
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.0f)),
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 1.25f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 1.25f)),
					unityList.get(REGISTER_BANK).getEntryPoint(Reg_Bank.ENTRY_TOP)));
		
		// 3 reg id if - reg bank
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
				new Wire(
					unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE),
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.0f)),
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.95f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.95f)),
					unityList.get(REGISTER_BANK).getEntryPoint(Reg_Bank.ENTRY_TOP_2)));
		
		// 4 reg id if - reg bank
		wireComp.add(new CompWire(
				new Wire(
						new Vector2(unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)), 
						unityList.get(REGISTER_BANK).getEntryPoint(Register.ENTRY_BOTTOM))));

		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// FIOS REG BANK   -------------------------------------------
		// 5 reg bank - reg id ex
		wireComp.add(new CompWire(new Wire(new Vector2(unityList.get(REGISTER_BANK).getOutputPoint(Reg_Bank.OUTPUT_TOP)), unityList.get(REGISTER_ID_EX).getEntryPoint(Register.ENTRY_TOP))));
		// 6 reg bank - reg id ex
		wireComp.add(new CompWire(new Wire(new Vector2(unityList.get(REGISTER_BANK).getOutputPoint(Reg_Bank.OUTPUT_BOTTOM)), unityList.get(REGISTER_ID_EX).getEntryPoint(Register.ENTRY_MIDDLE))));
		
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// Fios ID/EX
		// 7 re id ex - ula add
		wireComp.add(new CompWire(new Wire((new Vector2(unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_TOP_2))), unityList.get(ULA_ADD_4).getEntryPoint(ULA.ENTRY_TOP))));
		
		// 8 reg id ex - mux
		wireComp.add(new CompWire(new Wire(new Vector2(unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_MIDDLE)), unityList.get(MUX_EX).getEntryPoint(MUX.ENTRY_TOP))));
		// 9 reg id ex - ula ex
		wireComp.add(new CompWire(new Wire(new Vector2(unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_TOP)), unityList.get(ULA_EX).getEntryPoint(ULA.ENTRY_TOP))));
		
		// 10 reg id ex - reg ex mem
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_MIDDLE),
					new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, -1.7f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, -1.7f)),
						unityList.get(REGISTER_EX_MEM).getEntryPoint(Register.ENTRY_BOTTOM)));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		// Fios MUX EX
		
		// 11 mux ex - ula ex
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(MUX_EX).getOutputPoint(MUX.OUTPUT),
					new Vector2((unityList.get(MUX_EX).getOutputPoint(MUX.OUTPUT)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(MUX_EX).getOutputPoint(MUX.OUTPUT)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(MUX_EX).getOutputPoint(MUX.OUTPUT)).add(0.3f, 0.75f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(MUX_EX).getOutputPoint(MUX.OUTPUT)).add(0.3f, 0.75f)),
						unityList.get(ULA_EX).getEntryPoint(ULA.ENTRY_BOTTOM)));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// Fios ULA
		// 12 ula - reg ex mem
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(ULA_EX).getOutputPoint(ULA.OUTPUT),
					new Vector2((unityList.get(ULA_EX).getOutputPoint(ULA.OUTPUT)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(ULA_EX).getOutputPoint(ULA.OUTPUT)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(ULA_EX).getOutputPoint(ULA.OUTPUT)).add(0.3f, 0.5f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(ULA_EX).getOutputPoint(ULA.OUTPUT)).add(0.3f, 0.5f)),
						unityList.get(REGISTER_EX_MEM).getEntryPoint(Register.ENTRY_TOP)));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		// Fios EX/MEM
		// 13 reg ex mem- data mem
		wireComp.add(new CompWire(new Wire((new Vector2(unityList.get(REGISTER_EX_MEM).getOutputPoint(Register.OUTPUT_TOP))), unityList.get(DATA_MEM).getEntryPoint(Data_Mem.ENTRY_TOP))));
		
		// 14 reg ex mem - data mem
		wireComp.add(new CompWire(new Wire((new Vector2(unityList.get(REGISTER_EX_MEM).getOutputPoint(Register.OUTPUT_MIDDLE))), unityList.get(DATA_MEM).getEntryPoint(Data_Mem.ENTRY_BOTTOM))));
	
		// 15 reg ex mem - reg mem wb
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(REGISTER_EX_MEM).getOutputPoint(Register.OUTPUT_TOP),
					new Vector2((unityList.get(REGISTER_EX_MEM).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_EX_MEM).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(REGISTER_EX_MEM).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, -2.95f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_EX_MEM).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, -2.95f)),
						unityList.get(REGISTER_MEM_WB).getEntryPoint(Register.ENTRY_BOTTOM)));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// Fios Data Mem
		
		// 16 data mem - reg mem wb
		wireComp.add(new CompWire(new Wire((new Vector2(unityList.get(DATA_MEM).getOutputPoint(Data_Mem.OUTPUT_TOP))), unityList.get(REGISTER_MEM_WB).getEntryPoint(Register.ENTRY_TOP))));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// Fios MEM/WB
		
		// 17 reg mem wb - mux
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_TOP),
					new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, -0.1f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_TOP)).add(0.3f, -0.1f)),
						unityList.get(MUX_WB).getEntryPoint(MUX.ENTRY_TOP)));
		
		// 18 reg mem wb - mux
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_MIDDLE),
					new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, 0.15f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_MEM_WB).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.3f, 0.15f)),
						unityList.get(MUX_WB).getEntryPoint(MUX.ENTRY_BOTTOM)));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		// Fios ULA PC
		
		// 19 ula pc - reg if id
		wireComp.add(new CompWire(new Wire((new Vector2(unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT))), unityList.get(REGISTER_IF_ID).getEntryPoint(Register.ENTRY_TOP_2))));
		
		
		// 20 ula pc - mux_pc
		wireComp.add(new CompWire(5));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(new Wire(
					unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT),
					new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(0.5f, 0.0f))));
		wireComp.get(indexWireComp).addWire(new Wire(
					(new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(0.5f, 0.0f))),
					new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(0.5f, 1.5f))));
		wireComp.get(indexWireComp).addWire(new Wire(
				new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(0.5f, 1.5f)),
				new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(-4.7f, 1.5f))));
		wireComp.get(indexWireComp).addWire(new Wire(
				new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(-4.7f, 1.5f)),
				new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(-4.7f, -0.75f))));
		wireComp.get(indexWireComp).addWire(new Wire(
				new Vector2((unityList.get(ULA_PC).getOutputPoint(ULA.OUTPUT)).add(-4.7f, -0.75f)),
				new Vector2((unityList.get(MUX_PC).getEntryPoint(MUX.ENTRY_TOP)))));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// Fios MUX_WB
		
		// 21 mux wb - reg bank
		wireComp.add(new CompWire(5));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(new Wire(
					unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT),
					new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(0.5f, 0.0f))));
		wireComp.get(indexWireComp).addWire(new Wire(
					(new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(0.5f, 0.0f))),
					new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(0.5f, -3.5f))));
		wireComp.get(indexWireComp).addWire(new Wire(
				new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(0.5f, -3.5f)),
				new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(-13.75f, -3.5f))));
		wireComp.get(indexWireComp).addWire(new Wire(
				new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(-13.75f, -3.5f)),
				new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(-13.75f, -1.0f))));
		wireComp.get(indexWireComp).addWire(new Wire(
				new Vector2((unityList.get(MUX_WB).getOutputPoint(MUX.OUTPUT)).add(-13.75f, -1.0f)),
				new Vector2((unityList.get(REGISTER_BANK).getEntryPoint(Reg_Bank.ENTRY_BOTTOM_2)))));
		// -----------------------------------------------------------
		// -----------------------------------------------------------		
		
		
		// Fios ULA ADD 4
		
		// 22 ula add - mux_pc
		wireComp.add(new CompWire(5));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(new Wire(
				unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT),
				new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(2.5f, 0.0f))));
		wireComp.get(indexWireComp).addWire(new Wire(
				(new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(2.5f, 0.0f))),
				new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(2.5f, 2.5f))));
		wireComp.get(indexWireComp).addWire(new Wire(
			new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(2.5f, 2.5f)),
			new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(-15.0f, 2.5f))));
		wireComp.get(indexWireComp).addWire(new Wire(
			new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(-15.0f, 2.5f)),
			new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(-15.0f, -1.25f))));
		wireComp.get(indexWireComp).addWire(new Wire(
			new Vector2((unityList.get(ULA_ADD_4).getOutputPoint(ULA.OUTPUT)).add(-15.0f, -1.25f)),
			new Vector2((unityList.get(MUX_PC).getEntryPoint(MUX.ENTRY_BOTTOM)))));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// Fios MUX PC
		
		// 23 mux pc - pc
		wireComp.add(new CompWire(
				new Wire(
						(new Vector2(unityList.get(MUX_PC).getOutputPoint(MUX.OUTPUT))), 
						unityList.get(PC).getEntryPoint(CPU.ENTRY))));
		// -----------------------------------------------------------
		// -----------------------------------------------------------
		
		
		// Fios PC
		
		// 24 pc - blk instruction
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(PC).getOutputPoint(CPU.OUTPUT),
					new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, -1.6f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, -1.6f)),
						unityList.get(BLK_INTRUCTION).getEntryPoint(StdBlock.ENTRY_TOP)));
		
		// 25 pc - ula pc
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(PC).getOutputPoint(CPU.OUTPUT),
					new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, 0.0f)),
						new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, 1.75f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(PC).getOutputPoint(CPU.OUTPUT)).add(0.3f, 1.75f)),
						unityList.get(ULA_PC).getEntryPoint(ULA.ENTRY_TOP)));
		
		// 26 reg id if - sign extend
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
				new Wire(
					unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE),
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, 0.0f)),
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.5f, -1.85f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
					new Vector2((unityList.get(REGISTER_IF_ID).getOutputPoint(Register.OUTPUT_MIDDLE)).add(0.48f, -1.85f)),
					unityList.get(SIGN_EXTEND).getEntryPoint(SignExtend.ENTRY)));
				
		// 27 sign extend - reg id ex
		wireComp.add(new CompWire(
				new Wire(
						(new Vector2(unityList.get(SIGN_EXTEND).getOutputPoint(SignExtend.OUTPUT))), 
						unityList.get(REGISTER_ID_EX).getEntryPoint(Register.ENTRY_BOTTOM))));
		
		// 28 reg id ex - mux
		wireComp.add(new CompWire(
				new Wire(
						new Vector2(unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_BOTTOM_2)),
						unityList.get(MUX_EX).getEntryPoint(MUX.ENTRY_BOTTOM))));
		
		// 29 mux ex - ula ex
		wireComp.add(new CompWire(3));
		indexWireComp = wireComp.size()-1;
		wireComp.get(indexWireComp).addWire(
					new Wire(unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_BOTTOM_2),
					new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_BOTTOM_2)).add(0.1f, 0.0f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_BOTTOM_2)).add(0.15f, 0.0f)),
						new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_BOTTOM_2)).add(0.15f, 4.1f))));
		wireComp.get(indexWireComp).addWire(
				new Wire(
						new Vector2((unityList.get(REGISTER_ID_EX).getOutputPoint(Register.OUTPUT_BOTTOM_2)).add(0.15f, 4.1f)),
						unityList.get(ULA_ADD_4).getEntryPoint(ULA.ENTRY_BOTTOM)));
	 
	
		
		//30 pc - mux pc
		wireComp.add(new CompWire(wireComp.get(25), wireComp.get(20)));
		//31 pc - reg if id
		wireComp.add(new CompWire(wireComp.get(25), wireComp.get(19)));
		//32 pc - reg if id
		wireComp.add(new CompWire(wireComp.get(24), wireComp.get(0)));
		
		//33 reg if id - reg id ex
		wireComp.add(new CompWire(wireComp.get(2), wireComp.get(5)));
		//34 o mesmo mas pra lw
		wireComp.add(new CompWire(wireComp.get(2), wireComp.get(6)));
		
		//35 reg id ex mux ula
		wireComp.add(new CompWire(wireComp.get(8), wireComp.get(11)));
		//36 reg id ex mux ula
		wireComp.add(new CompWire(wireComp.get(35), wireComp.get(12)));
		//37 reg id ex mux ula
		wireComp.add(new CompWire(wireComp.get(18), wireComp.get(21)));
		//38 reg id if  sign extend - sign extend  reg id ex
		wireComp.add(new CompWire(wireComp.get(26), wireComp.get(27)));
		//39 reg id ex mux - mux ex ula ex
		wireComp.add(new CompWire(wireComp.get(28), wireComp.get(11)));
		//40 reg id ex mux - ula reg ex me
		wireComp.add(new CompWire(wireComp.get(39), wireComp.get(12)));
		//41 reg ex mem data mem - data mem reg mem wb
		wireComp.add(new CompWire(wireComp.get(13), wireComp.get(16)));
		//42 reg mem wb mux - mux wb reg bank
		wireComp.add(new CompWire(wireComp.get(17), wireComp.get(21)));
		//43 reg id ex mux ula
		wireComp.add(new CompWire(wireComp.get(28), wireComp.get(11)));
		//44 reg id ex mux ula
		wireComp.add(new CompWire(wireComp.get(43), wireComp.get(12)));
		
		//45 mux ex ula add - ula add mux_pc
		wireComp.add(new CompWire(wireComp.get(29), wireComp.get(22)));

		loadInstructions();
	}
	
	public void resetAll() {
		pipelineSwicth = true;
		for(CompWire cwire : wireComp) {
			cwire.reset();
		}
	}
	
	public void executePlay() {
		if(!runningCycle) {
			runningCycle = true;
		}
		
		executePipeline();
		
		
	}
	
	public void update(float deltaTime)
	{
		controlCamera(deltaTime);
	
		
		if(Gdx.input.isKeyJustPressed(Keys.SPACE) && !runningCycle)
			runningCycle = true;
		
		if(!runningCycle)
			return;
		
		// Atualiza fios para anima��o
		updateWireConections(deltaTime);
		
	}
	
	private void controlCamera(float deltaTime) {
		if (!cameraHelper.hasTarget()) {
			float cameraMoveSpeed = 5.0f * deltaTime;
			if (Gdx.input.isKeyPressed(Keys.W)) {
				moveCamera(0.0f, cameraMoveSpeed);
			}
			if (Gdx.input.isKeyPressed(Keys.A)) {
				moveCamera(-cameraMoveSpeed, 0.0f);
			}
			if (Gdx.input.isKeyPressed(Keys.S)) {
				moveCamera(0.0f, -cameraMoveSpeed);
			}
			if (Gdx.input.isKeyPressed(Keys.D)) {
				moveCamera(cameraMoveSpeed, 0.0f);		
			}
		}
		
		cameraHelper.update(deltaTime);
	}
	
	private void moveCamera(float x, float y) {
		x += cameraHelper.getPosition().x;
		y += cameraHelper.getPosition().y;
		cameraHelper.setPosition(x, y);
	}
	
	
	private void updateWireConections(float deltaTime) {

		boolean reset = true;
		
		for(CompWire cwire : wireComp) {
			cwire.update(deltaTime);
			if(!cwire.isDone())
				reset = false;
		}
		
		if(reset){
			for(CompWire cwire : wireComp) {
				cwire.reset();
				cwire.start();
			}
			runningCycle = false;
			cycle = 0;
		}

	}
	
	public void executePipeline() {
		
		if(indexInstruction == 14)
			runningCycle = false;
		
		pipeline[0] = instructions[indexInstruction];

		//0 R
		//1 LW
		//2 SW
		//3 bne
		
		for(int i = 0; i < 5; i++) {
			if(pipeline[i] == 0) {
				typeRInstruction(i);
			}
			if(pipeline[i] == 1) {
				typeILoadInstruction(i);
			}
			if(pipeline[i] == 2) {
				typeIStoreInstruction(i);
			}
			if(pipeline[i] == 3) {
				typeIBNEInstruction(i);
			}
		}

		if(pipelineSwicth) {
			for(int i = 4; i >= 1; i--) {
				pipeline[i] = pipeline[i-1];
			}
			
			/*((Register) unityList.get(10)).setInstruction(((Register) unityList.get(8)).instruction);
			((Register) unityList.get(8)).setInstruction(((Register) unityList.get(4)).instruction);
			((Register) unityList.get(4)).setInstruction(((Register) unityList.get(2)).instruction);*/
			//((Register) unityList.get(2)).instruction = instText[indexInstruction];
			System.out.println(instText[indexInstruction]);
			indexInstruction++;
		}
		pipelineSwicth = false;
		
	}
	
	public void loadInstructions() {
		BufferedReader br = null;
		FileReader fr = null;
		
		try {
			fr = new FileReader("instruction.txt");
			br = new BufferedReader(fr);
			
			String sCurrentLine;
			String array[] = new String[4];

			int i = 0;
			instructions = new int[15];
			
			while((sCurrentLine = br.readLine()) != null) {
				instText[i] = sCurrentLine;
				array = sCurrentLine.split(" ");
				if(array[0].equals("ADD") || array[0].equals("SUB") || array[0].equals("AND") || array[0].equals("OR")) {
					instructions[i++] = 0;
				}
				if(array[0].equals("LW")) {
					instructions[i++] = 1;
				}
				if(array[0].equals("SW")) {
					instructions[i++] = 2;
				}
				if(array[0].equals("BNE")) {
					instructions[i++] = 3;
				}
			}			
			for(i = i; i < 15; i++)
				instructions[i] = -1;
			
		}catch ( IOException e) {
			e.printStackTrace();
		}finally {
			try {
				if(br != null)
					br.close();
				
				if(fr != null)
					fr.close();
			}catch(IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
public void typeRInstruction(int cc) {
		
		switch (cc) {
			case 0:
				
				wireComp.get(30).start();
				wireComp.get(31).start();
				wireComp.get(32).start();
				
				if(wireComp.get(32).isDone()) {
					resetAll();
					cycle++;
				}
				
				break;
			case 1:
				wireComp.get(33).start();
				wireComp.get(3).start();
				wireComp.get(23).start();
				wireComp.get(34).start();
				
				if(wireComp.get(34).isDone()) {
					cycle++;
					resetAll();
				}
					
				break;
			case 2:
				wireComp.get(35).start();
				wireComp.get(9).start();
				wireComp.get(10).start();
				
				if(wireComp.get(35).isDone()) {
					cycle++;
					resetAll();
				}
				break;
			case 3:	
				wireComp.get(15).start();
				
				if(wireComp.get(15).isDone()) {
					resetAll();
					cycle++;
				}
				
				break;
			case 4:
				wireComp.get(37).start();
				
				if(wireComp.get(37).isDone()) {
					resetAll();
					cycle = 0;
				}
				break;
		}
	}
	

	public void typeILoadInstruction(int cc) {
		
		switch (cc) {
			case 0:
				wireComp.get(30).start();
				wireComp.get(31).start();
				wireComp.get(32).start();
				
				if(wireComp.get(32).isDone()){
					cycle++;
					resetAll();
				}
					
				break;
			case 1:
				wireComp.get(33).start();
				wireComp.get(34).start();
				wireComp.get(38).start();

				if(wireComp.get(38).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 2:
				wireComp.get(39).start();
				wireComp.get(40).start();
				wireComp.get(10).start();

				if(wireComp.get(40).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 3:	
				wireComp.get(14).start();
				wireComp.get(41).start();

				if(wireComp.get(41).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 4:
				wireComp.get(40).start();
								
				if(wireComp.get(40).isDone()){
					cycle = 0;
					resetAll();
				}
				break;
		}
	}

	public void typeIStoreInstruction(int cc) {
		
		switch (cc) {
			case 0:
				wireComp.get(30).start();
				wireComp.get(31).start();
				wireComp.get(32).start();
				
				if(wireComp.get(32).isDone()){
					cycle++;
					resetAll();
				}
					
				break;
			case 1:
				wireComp.get(33).start();
				wireComp.get(4).start();
				wireComp.get(38).start();

				if(wireComp.get(38).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 2:
				wireComp.get(9).start();
				wireComp.get(10).start();
				wireComp.get(43).start();
				wireComp.get(44).start();

				if(wireComp.get(44).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 3:	
				wireComp.get(13).start();
				wireComp.get(14).start();

				if(wireComp.get(14).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 4:
				break;
		}
	}
	
public void typeIBNEInstruction(int cc) {
		
		switch (cc) {
			case 0:
				wireComp.get(30).start();
				wireComp.get(31).start();
				wireComp.get(32).start();
				
				if(wireComp.get(32).isDone()){
					cycle++;
					resetAll();
				}
					
				break;
			case 1:
				wireComp.get(1).start();

				if(wireComp.get(1).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 2:
				wireComp.get(7).start();
				wireComp.get(22).start();
				wireComp.get(23).start();

				if(wireComp.get(23).isDone()){
					cycle++;
					resetAll();
				}
				break;
			case 3:	
				break;
			case 4:
				break;
		}
	}

	@Override
	public boolean keyDown(int keycode) { return false; }

	@Override
	public boolean keyUp(int keycode) { return false; }

	@Override
	public boolean keyTyped(char character) { return false; }

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) { return false; }

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) { return false; }

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) { return false; }

	@Override
	public boolean mouseMoved(int screenX, int screenY) { return false; }

	@Override
	public boolean scrolled(int amount) {
		float zoomSpeed = 0.2f * amount;
		
		cameraHelper.addZoom(zoomSpeed);
		
		return false;
	}
	
}
