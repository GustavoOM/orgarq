package br.usp.components.wire;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;

import br.usp.utils.Constants;

public class Wire {
	
	private float speed = 1.0f;
	
	private Vector2 startPoint;
	private Vector2 endPoint;
	
	private Vector2 currentPoint;
	
	private boolean started;
	private boolean done;
	
	public Wire(Vector2 startPoint, Vector2 endPoint) {
		this.startPoint = startPoint;
		this.endPoint = endPoint;
		
		currentPoint = new Vector2(startPoint);
		
		started = false;
		done = false;
		
		Vector2 dist = new Vector2(endPoint).sub(startPoint);
		float auxspeed = Math.abs(dist.len());
		if(auxspeed > 10) {
			speed = 10;
		}else if(auxspeed < 10 && auxspeed > 5) {
			speed = 5;
		}else {
			speed = 2;
		}
	}
	
	public void update(float deltaTime) {
		if (!started)
			return;
		
		float dt = speed * deltaTime;
		
		currentPoint.x = approach(endPoint.x, currentPoint.x, dt);
		currentPoint.y = approach(endPoint.y, currentPoint.y, dt);
		
		if (currentPoint.x == endPoint.x && currentPoint.y == endPoint.y) {
			started = false;
			done = true;
		}
	}
	
	public void reset() {
		currentPoint.set(startPoint);
		done = false;
		started = false;
	}
	
	public void start() {
		started = true;
	}
	
	public boolean hasStarted() {
		return started;
	}
	
	public boolean isDone() {
		return done;
	}
	
	public void render(ShapeRenderer shapeRenderer) {
		shapeRenderer.setColor(Constants.LINE_COLOR);
		shapeRenderer.line(startPoint, endPoint);
		
		shapeRenderer.setColor(Constants.DARK_RED);
		shapeRenderer.line(startPoint, currentPoint);
	}
	
	private float approach(float goal, float current, float dt) {
		float diff = goal - current;
		
		if (diff > dt) 
			return current + dt;
		else if (diff < -dt)
			return current - dt;
		else 
			return goal;
	}
	
}
