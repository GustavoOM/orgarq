package br.usp.components;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public abstract class Unity {

	public Sprite sprite;
	
	protected List<Vector2> entryPoints;
	protected List<Vector2> outputPoints;
	
	public Unity(Vector2 position, Texture texture, float width, float height) {
		sprite = createSprite(texture, width, height);
		sprite.setPosition(position.x, position.y);
		
		entryPoints = new ArrayList<Vector2>();
		outputPoints = new ArrayList<Vector2>();
		
		createEntryPoints();
		createOutputPoints();
	}
	
	protected abstract void createEntryPoints();
	protected abstract void createOutputPoints();
	
	public Vector2 getEntryPoint(int point) {
		if (point < 0 || point >= entryPoints.size())
			return null;
		
		return new Vector2(entryPoints.get(point)).add(sprite.getX(), sprite.getY());
	}
	
	public Vector2 getOutputPoint(int point) {
		if (point < 0 || point >= outputPoints.size())
			return null;
		
		return new Vector2(outputPoints.get(point)).add(sprite.getX(), sprite.getY());
	}
	
	public void render(SpriteBatch batch) {
		sprite.draw(batch);
	}
	
	private static Sprite createSprite(Texture texture, float width, float height) {
		Sprite sprite = new Sprite(texture);
		sprite.setSize(width, height);
		sprite.setOriginCenter();
		return sprite;
	}
	
}
