package br.usp.components;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;

import br.usp.utils.Constants;

public class Wire {
	
	private static final float SPEED = 1.0f;
	
	private Vector2 startPoint;
	private Vector2 endPoint;
	
	private Vector2 currentPoint;
	
	public Wire(Vector2 startPoint, Vector2 endPoint) {
		this.startPoint = startPoint;
		this.endPoint = endPoint;
		
		currentPoint = new Vector2(startPoint);
	}
	
	public void update(float deltaTime) {
		float dt = SPEED * deltaTime;
		
		currentPoint.x = approach(endPoint.x, currentPoint.x, dt);
		currentPoint.y = approach(endPoint.y, currentPoint.y, dt);
		
		if (currentPoint.x == endPoint.x && currentPoint.y == endPoint.y)
			currentPoint.set(startPoint);
	}
	
	public void render(ShapeRenderer shapeRenderer) {
		shapeRenderer.setColor(Constants.LINE_COLOR);
		shapeRenderer.line(startPoint, endPoint);
		
		shapeRenderer.setColor(Constants.DARK_RED);
		shapeRenderer.line(startPoint, currentPoint);
	}
	
	private float approach(float goal, float current, float dt) {
		float diff = goal - current;
		
		if (diff > dt) 
			return current + dt;
		else if (diff < -dt)
			return current - dt;
		else 
			return goal;
	}
	
}
