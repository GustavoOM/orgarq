package br.usp.components;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class ULA extends Unity {
	
		// Porpriedades
		private static final Texture TEXTURE = new Texture("ula.png");
		private static final float WIDTH = 1.0f;
		private static final float HEIGHT = 2.0f;
		
		// Pontos de entrada
		public static final int ENTRY_TOP = 0;
		public static final int ENTRY_BOTTOM = 1;
		
		// Pontos de saida
		public static final int OUTPUT = 0;
		
		public ULA(float x, float y) {
			super(new Vector2(x, y), TEXTURE, WIDTH, HEIGHT);
		}
		
		@Override
		protected void createEntryPoints() {
			entryPoints.add(new Vector2(0.0f, 1.5f));
			entryPoints.add(new Vector2(0.0f, 0.5f));
		}
		
		@Override
		protected void createOutputPoints() {
			outputPoints.add(new Vector2(WIDTH, HEIGHT / 2.0f));
		}
		
}
