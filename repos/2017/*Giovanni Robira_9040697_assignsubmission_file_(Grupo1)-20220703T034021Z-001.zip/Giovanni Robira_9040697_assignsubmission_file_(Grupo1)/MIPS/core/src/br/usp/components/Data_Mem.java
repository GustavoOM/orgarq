package br.usp.components;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Data_Mem extends Unity {
	
	// Porpriedades
	private static final Texture TEXTURE = new Texture("data_mem.png");
	private static final float WIDTH = 2.5f;
	private static final float HEIGHT = 2.5f;
	
	// Pontos de entrada
	public static final int ENTRY_TOP = 0;
	public static final int ENTRY_BOTTOM = 1;
	
	// Pontos de saida
	public static final int OUTPUT_TOP = 0;
	public static final int OUTPUT_BOTTOM = 1;
	
	public Data_Mem(float x, float y) {
		super(new Vector2(x, y), TEXTURE, WIDTH, HEIGHT);
	}
	
	@Override
	protected void createEntryPoints() {
		entryPoints.add(new Vector2(0.0f, 1.9f));
		entryPoints.add(new Vector2(0.0f, 0.65f));
	}
	
	@Override
	protected void createOutputPoints() {
		outputPoints.add(new Vector2(WIDTH, 1.9f));
		outputPoints.add(new Vector2(WIDTH, 0.65f));
	}
}
