package br.usp.components;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class CPU extends Unity{

	// Porpriedades
		private static final Texture TEXTURE = new Texture("pc.png");
		private static final float WIDTH = 1.0f;
		private static final float HEIGHT = 1.5f;
		
		// Pontos de entrada
		public static final int ENTRY = 0;
		
		// Pontos de saida
		public static final int OUTPUT = 0;
		
		public CPU(float x, float y) {
			super(new Vector2(x, y), TEXTURE, WIDTH, HEIGHT);
		}
		
		@Override
		protected void createEntryPoints() {
			entryPoints.add(new Vector2(0.0f, 0.65f));
		}
		
		@Override
		protected void createOutputPoints() {
			outputPoints.add(new Vector2(WIDTH, 0.65f));
		}
}
