package br.usp.utils;

import com.badlogic.gdx.graphics.Color;

public class Constants {
	public static final float VIEWPORT_WIDTH = 5.0f;
	public static final float VIEWPORT_HEIGHT = 5.0f;
	
	// Cores
	public static final Color LINE_COLOR = new Color(44.0f/255.0f, 62.0f/255.0f, 80.0f/255.0f, 1.0f);
	public static final Color DARK_RED = new Color(255.0f/255.0f, 67.0f/255.0f, 73.0f/255.0f, 1.0f);
}
