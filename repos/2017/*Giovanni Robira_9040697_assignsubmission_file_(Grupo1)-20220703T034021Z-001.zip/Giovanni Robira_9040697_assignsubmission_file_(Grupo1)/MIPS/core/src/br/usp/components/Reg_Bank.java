package br.usp.components;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Reg_Bank extends Unity {
	
	// Porpriedades
	private static final Texture TEXTURE = new Texture("register.png");
	private static final float WIDTH = 2.5f;
	private static final float HEIGHT = 2.5f;
	
	// Pontos de entrada
	public static final int ENTRY_TOP = 0;
	public static final int ENTRY_TOP_2 = 1;
	public static final int ENTRY_BOTTOM = 2;
	public static final int ENTRY_BOTTOM_2 = 3;
	
	// Pontos de saida
	public static final int OUTPUT_TOP = 0;
	public static final int OUTPUT_BOTTOM = 1;
	
	public Reg_Bank(float x, float y) {
		super(new Vector2(x, y), TEXTURE, WIDTH, HEIGHT);
	}
	
	@Override
	protected void createEntryPoints() {
		entryPoints.add(new Vector2(0.0f, 1.9f));
		entryPoints.add(new Vector2(0.0f, 1.6f));
		entryPoints.add(new Vector2(0.0f, 0.65f));
		entryPoints.add(new Vector2(0.0f, 0.3f));
	}
	
	@Override
	protected void createOutputPoints() {
		outputPoints.add(new Vector2(WIDTH, 1.9f));
		outputPoints.add(new Vector2(WIDTH, 0.65f));
	}
}

